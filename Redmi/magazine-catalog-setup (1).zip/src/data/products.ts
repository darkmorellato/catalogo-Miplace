export interface ProductSpec {
  label: string;
  value: string;
}

export interface ProductHighlight {
  title: string;
  text: string;
}

export interface Product {
  id: number;
  brand: string;
  name: string;
  highlight: boolean;
  image: string;
  price: string;
  specialPrice?: string;
  description: string;
  specs: ProductSpec[];
  highlights: ProductHighlight[];
  gallery: string[];
}

export const productsData: Product[] = [
  {
    id: 1,
    brand: 'Realme',
    name: 'REALME C61',
    highlight: false,
    image: 'Realme/c61-1.png',
    price: 'A partir de R$ 1.499',
    description: 'O Realme C61 é um smartphone básico/intermediário focado em durabilidade e custo-benefício. Destaca-se pela bateria de 5.000 mAh com ótima autonomia, câmera principal de 50 MP, tela de 6,74" (90 Hz) e proteção IP54 contra água/poeira, sendo ideal para uso diário.',
    specs: [
      { label: 'Processador', value: 'Unisoc T612' },
      { label: 'Memória RAM', value: '4 GB, 6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,74" IPS LCD, HD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '5.000 mAh (15W)' },
      { label: 'Sistema', value: 'Android 14 (Realme UI)' },
      { label: 'Recursos', value: 'IP54, NFC, P2, Mini Cápsula 2.0' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para ser robusto, com boa resistência a quedas.' },
      { title: 'Design', text: 'Corpo fino (7,8 mm) e disponível nas cores Verde e Dourado.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte).' }
    ],
    gallery: ['Realme/c61-1.png', 'Realme/c61-2.png', 'Realme/c61-3.png', 'Realme/c61-4.png']
  },
  {
    id: 2,
    brand: 'Realme',
    name: 'REALME C63',
    highlight: false,
    image: 'Realme/c63-1.png',
    price: 'A partir de R$ 1.499',
    description: 'O Realme C63 é um smartphone básico/intermediário focado em durabilidade e custo-benefício. Destaca-se pela bateria de 5.000 mAh com ótima autonomia, câmera principal de 50 MP, tela de 6,74" (90 Hz) e proteção IP54 contra água/poeira, sendo ideal para uso diário.',
    specs: [
      { label: 'Processador', value: 'Unisoc T612' },
      { label: 'Memória RAM', value: '6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,74" IPS LCD, HD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '5.000 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 14 (Realme UI)' },
      { label: 'Recursos', value: 'IP54, NFC, P2, Alto-falante mono, Mini Cápsula 2.0' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para ser robusto, com boa resistência a quedas.' },
      { title: 'Design', text: 'Corpo fino (7,8 mm) e disponível nas cores Verde e Azul.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte), mas pode sofrer com jogos pesados.' }
    ],
    gallery: ['Realme/c63-1.png', 'Realme/c63-2.png', 'Realme/c63-3.png', 'Realme/c63-4.png']
  },
  {
    id: 3,
    brand: 'Realme',
    name: 'REALME C67',
    highlight: false,
    image: 'Realme/c67-1.png',
    price: 'A partir de R$ 1.499',
    description: 'O Realme C67 é um smartphone de entrada avançado que se destaca pela sua câmera de 108 MP e design elegante com certificação IP54 contra poeira e respingos.',
    specs: [
      { label: 'Processador', value: 'Snapdragon 685' },
      { label: 'Memória RAM', value: '6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,72" IPS LCD, FHD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 108 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '5.000 mAh (Carregamento 33W)' },
      { label: 'Sistema', value: 'Android 14 (Realme UI)' },
      { label: 'Recursos', value: 'IP54' }
    ],
    highlights: [
      { title: 'Câmera', text: 'Câmera principal de 108 MP com excelente qualidade de imagem.' },
      { title: 'Design', text: 'Corpo fino (7,6 mm) e disponível nas cores Verde e Preto.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte), bom desempenho em jogos.' }
    ],
    gallery: ['Realme/c67-1.png', 'Realme/c67-2.png', 'Realme/c67-3.png', 'Realme/c67-4.png']
  },
  {
    id: 4,
    brand: 'Realme',
    name: 'REALME C71',
    highlight: false,
    image: 'Realme/c71-1.png',
    price: 'A partir de R$ 1.399',
    description: 'O Realme C71 é um smartphone de entrada que se destaca pela sua câmera de 50 MP e design elegante com certificação IP54 contra poeira e respingos.',
    specs: [
      { label: 'Processador', value: 'Unisoc T7250' },
      { label: 'Memória RAM', value: '4 GB, 6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,67" IPS LCD, HD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '6.000 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 15 com a interface Realme UI 6.0' },
      { label: 'Recursos', value: 'IP54, NFC, P2' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,5 metros.' },
      { title: 'Design', text: 'Corpo fino (7,8 mm) e disponível nas cores Verde e Branco.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte), mas pode sofrer com jogos pesados.' }
    ],
    gallery: ['Realme/c71-1.png', 'Realme/c71-2.png', 'Realme/c71-3.png', 'Realme/c71-4.png']
  },
  {
    id: 5,
    brand: 'Realme',
    name: 'REALME C75/C75X',
    highlight: false,
    image: 'Realme/c75-1.png',
    price: 'A partir de R$ 1.699',
    description: 'O Realme C75 é um smartphone de entrada que se destaca pela sua câmera de 50 MP e design elegante com certificação IP68/IP69 até 1,5 metros por 25 minutos.',
    specs: [
      { label: 'Processador', value: 'Mediatek Helio G92 Max' },
      { label: 'Memória RAM', value: '6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,72" IPS LCD, FHD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '6.000 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 14 com a interface Realme UI 5.0' },
      { label: 'Recursos', value: 'IP68/IP69, NFC' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,5 metros.' },
      { title: 'Design', text: 'Corpo fino (8 mm) e disponível nas cores Dourado, Preto, Rosa, Azul e Vermelho.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte), mas pode sofrer com jogos pesados.' }
    ],
    gallery: ['Realme/c75-1.png', 'Realme/c75-2.png', 'Realme/c75-3.png', 'Realme/c75-4.png']
  },
  {
    id: 6,
    brand: 'Realme',
    name: 'REALME C85',
    highlight: false,
    image: 'Realme/c85-1.png',
    price: 'A partir de R$ 1.899',
    description: 'O Realme C85 é um smartphone intermediário que se destaca pelo seu processador, design elegante com certificação IP68/IP69k até 6 metros por 30 minutos.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 6300' },
      { label: 'Memória RAM', value: '6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,8" IPS LCD, HD+, 144 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '7.000 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 15 (Realme UI 6.0)' },
      { label: 'Recursos', value: 'IP68/IP69k, NFC' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,5 metros.' },
      { title: 'Design', text: 'Corpo (8,4 mm) e disponível nas cores Azul e Preto.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias, bom desempenho em jogos.' }
    ],
    gallery: ['Realme/c85-1.png', 'Realme/c85-2.png', 'Realme/c85-3.png', 'Realme/c85-4.png']
  },
  {
    id: 7,
    brand: 'Realme',
    name: 'REALME C85 PRO',
    highlight: false,
    image: 'Realme/c85pro-1.png',
    price: 'A partir de R$ 2.099',
    description: 'O Realme C85 Pro é um smartphone intermediário que se destaca pelo seu processador, design elegante com certificação IP68/IP69k até 6 metros por 30 minutos.',
    specs: [
      { label: 'Processador', value: 'Snapdragon 685' },
      { label: 'Memória RAM', value: '6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,8" AMOLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '7.000 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 15 (Realme UI 6.0)' },
      { label: 'Recursos', value: 'IP68/IP69k, NFC' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,5 metros.' },
      { title: 'Design', text: 'Corpo (8,1 mm) e disponível nas cores Rosa e Verde.' },
      { title: 'Performance', text: 'Ótimo desempenho para tarefas diárias e jogos.' }
    ],
    gallery: ['Realme/c85pro-1.png', 'Realme/c85pro-2.png', 'Realme/c85pro-3.png', 'Realme/c85pro-4.png']
  },
  {
    id: 8,
    brand: 'Realme',
    name: 'REALME NOTE 70',
    highlight: false,
    image: 'Realme/note70-1.png',
    price: 'A partir de R$ 1.399',
    description: 'O Realme Note 70 é um smartphone de entrada com design elegante, certificação IP54 e personalização de LED traseiro.',
    specs: [
      { label: 'Processador', value: 'Unisoc T7250' },
      { label: 'Memória RAM', value: '4 GB ou 6 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,72" IPS LCD, HD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 13 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '6.300 mAh (Carregamento 15W)' },
      { label: 'Sistema', value: 'Android 15 (Realme UI 5.0)' },
      { label: 'Recursos', value: 'IP54' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,8 metros.' },
      { title: 'Design', text: 'Corpo (7,9 mm) e disponível nas cores Preto e Dourado.' },
      { title: 'Performance', text: 'Ótimo desempenho para tarefas diárias e internet.' }
    ],
    gallery: ['Realme/note70-1.png', 'Realme/note70-2.png', 'Realme/note70-3.png', 'Realme/note70-4.png']
  },
  {
    id: 9,
    brand: 'Honor',
    name: 'HONOR X5C',
    highlight: false,
    image: 'Honor/x5c-1.png',
    price: 'A partir de R$ 1.399',
    description: 'O Honor X5C é um smartphone de entrada com design elegante, NFC e certificação IP54.',
    specs: [
      { label: 'Processador', value: 'Mediatek Helio G81' },
      { label: 'Memória RAM', value: '4 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB' },
      { label: 'Tela', value: '6,74" TFT LCD, HD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '5.260 mAh (Carregamento 15W)' },
      { label: 'Sistema', value: 'Android 15 (Honor Magic OS 9)' },
      { label: 'Recursos', value: 'IP54, NFC' }
    ],
    highlights: [
      { title: 'Custo Benefício', text: 'Melhor custo benefício para o preço.' },
      { title: 'Design', text: 'Corpo (7,9 mm) e disponível nas cores Preto e Azul.' },
      { title: 'Performance', text: 'Ótimo desempenho para tarefas diárias com NFC.' }
    ],
    gallery: ['Honor/x5c-1.png', 'Honor/x5c-2.png', 'Honor/x5c-3.png', 'Honor/x5c-4.png']
  },
  {
    id: 10,
    brand: 'Honor',
    name: 'HONOR X5C PLUS',
    highlight: false,
    image: 'Honor/x5cplus-1.png',
    price: 'A partir de R$ 1.499',
    description: 'O Honor X5C Plus é um smartphone de entrada com design elegante e certificação IP54.',
    specs: [
      { label: 'Processador', value: 'Mediatek Helio G81' },
      { label: 'Memória RAM', value: '4 GB ou 6 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,74" TFT LCD, HD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '5.260 mAh (Carregamento 15W)' },
      { label: 'Sistema', value: 'Android 15 (Honor Magic OS 9)' },
      { label: 'Recursos', value: 'IP54, NFC' }
    ],
    highlights: [
      { title: 'Custo Benefício', text: 'Melhor custo benefício para o preço.' },
      { title: 'Design', text: 'Corpo (7,9 mm) e disponível nas cores Preto e Azul.' },
      { title: 'Performance', text: 'Ótimo desempenho para tarefas diárias.' }
    ],
    gallery: ['Honor/x5cplus-1.png', 'Honor/x5cplus-2.png', 'Honor/x5cplus-3.png', 'Honor/x5cplus-4.png']
  },
  {
    id: 11,
    brand: 'Honor',
    name: 'HONOR X7C',
    highlight: true,
    image: 'Honor/x7c-1.png',
    price: 'A partir de R$ 1.499',
    description: 'O Honor X7C é um smartphone intermediário com design elegante, 108 MP na câmera e com resistência a quedas.',
    specs: [
      { label: 'Processador', value: 'Snapdragon 685' },
      { label: 'Memória RAM', value: '8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB' },
      { label: 'Tela', value: '6,77" TFT LCD, HD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 108 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '6.000 mAh (Carregamento rápido de até 35W)' },
      { label: 'Sistema', value: 'Android 14 (Honor Magic OS 8)' },
      { label: 'Recursos', value: 'IP64, NFC (confirmar versão), resistência a quedas' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,2 metros.' },
      { title: 'Design', text: 'Corpo (8,1 mm) e disponível nas cores Preto, Branco e Verde.' },
      { title: 'Performance', text: 'Ótimo desempenho para tarefas diárias e jogos.' }
    ],
    gallery: ['Honor/x7c-1.png', 'Honor/x7c-2.png', 'Honor/x7c-3.png', 'Honor/x7c-4.png']
  },
  {
    id: 12,
    brand: 'Honor',
    name: 'HONOR X7D',
    highlight: false,
    image: 'Honor/x7d-1.png',
    price: 'A partir de R$ 1.899',
    description: 'O Honor X7D é um smartphone intermediário com design elegante com certificação IP65 e câmera de 108 MP.',
    specs: [
      { label: 'Processador', value: 'Snapdragon 685' },
      { label: 'Memória RAM', value: '8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB' },
      { label: 'Tela', value: '6,77" TFT LCD, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 108 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '6.500 mAh (Carregamento rápido de até 35W)' },
      { label: 'Sistema', value: 'Android 15 (Honor Magic OS 9)' },
      { label: 'Recursos', value: 'IP65, NFC, resistência a quedas' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para quedas de até 1,2 metros.' },
      { title: 'Design', text: 'Corpo (8,2 mm) e disponível nas cores Preto, Dourado, Prata e Azul.' },
      { title: 'Performance', text: 'Ótimo desempenho para tarefas diárias, fotos e jogos.' }
    ],
    gallery: ['Honor/x7d-1.png', 'Honor/x7d-2.png', 'Honor/x7d-3.png', 'Honor/x7d-4.png']
  },
  {
    id: 13,
    brand: 'Motorola',
    name: 'MOTO G05',
    highlight: false,
    image: 'Motorola/g05-1.png',
    price: 'A partir de R$ 999',
    description: 'O Moto G05 é um smartphone de entrada que se destaca pela sua bateria de 5.200 mAh e design resistente, ideal para uso diário.',
    specs: [
      { label: 'Processador', value: 'Mediatek Helio G81 Extreme' },
      { label: 'Memória RAM', value: '4 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,67" IPS LCD, HD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '5.200 mAh (Carregamento 18W)' },
      { label: 'Sistema', value: 'Android 15 (My UX)' },
      { label: 'Recursos', value: 'IP54' }
    ],
    highlights: [
      { title: 'Confiabilidade', text: 'Projeto com alta qualidade e durabilidade.' },
      { title: 'Design', text: 'Corpo fino (8,2 mm) e disponível nas cores Vermelho e Verde.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte).' }
    ],
    gallery: ['Motorola/g05-1.png', 'Motorola/g05-2.png', 'Motorola/g05-3.png', 'Motorola/g05-4.png']
  },
  {
    id: 14,
    brand: 'Motorola',
    name: 'MOTO G15',
    highlight: false,
    image: 'Motorola/g15-1.png',
    price: 'A partir de R$ 1.199',
    description: 'O Moto G15 é um smartphone de entrada que se destaca pela sua bateria de 5.200 mAh e design resistente, NFC ideal para uso diário.',
    specs: [
      { label: 'Processador', value: 'Mediatek Helio G81 Extreme' },
      { label: 'Memória RAM', value: '4 GB, 6 GB ou 8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB ou 256 GB' },
      { label: 'Tela', value: '6,72" IPS LCD, FHD+, 90 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 5 MP' },
      { label: 'Bateria', value: '5.200 mAh (Carregamento 18W)' },
      { label: 'Sistema', value: 'Android 15 (My UX)' },
      { label: 'Recursos', value: 'IP54, NFC' }
    ],
    highlights: [
      { title: 'Resistência', text: 'Projetado para ser robusto, com boa resistência a quedas.' },
      { title: 'Design', text: 'Corpo fino (8,2 mm) e disponível nas cores Cinza, Verde, Laranja e Azul.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte).' }
    ],
    gallery: ['Motorola/g15-1.png', 'Motorola/g15-2.png', 'Motorola/g15-3.png', 'Motorola/g15-4.png']
  },
  {
    id: 15,
    brand: 'Motorola',
    name: 'MOTO G56 5G',
    highlight: false,
    image: 'Motorola/g56-1.png',
    price: 'A partir de R$ 1.799',
    description: 'O Moto G56 5G é um smartphone intermediário que se destaca pela sua conectividade 5G, bateria de 5.000 mAh e design resistente, ideal para uso diário e streaming.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 7060' },
      { label: 'Memória RAM', value: '4 GB ou 6 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB, 256 GB ou 512 GB' },
      { label: 'Tela', value: '6,72" IPS LCD, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 32 MP' },
      { label: 'Bateria', value: '5.200 mAh (Carregamento 30W)' },
      { label: 'Sistema', value: 'Android 15 (My UX)' },
      { label: 'Recursos', value: 'IP68/IP69, NFC, Conectividade 5G, Resistência a quedas 1,2 metros' }
    ],
    highlights: [
      { title: 'Conectividade', text: 'Suporte a redes 5G para internet mais rápida.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias e streaming, jogos e multitarefa.' },
      { title: 'Design', text: 'Corpo fino (8,4 mm) e disponível nas cores Preto, Cinza e Azul.' }
    ],
    gallery: ['Motorola/g56-1.png', 'Motorola/g56-2.png', 'Motorola/g56-3.png', 'Motorola/g56-4.png']
  },
  {
    id: 16,
    brand: 'Motorola',
    name: 'MOTO G86 5G',
    highlight: true,
    image: 'Motorola/g86-1.png',
    price: 'A partir de R$ 2.099',
    description: 'O Moto G86 5G é um smartphone intermediário que se destaca pela sua conectividade 5G, bateria, design resistente, tela e performance ideal para uso diário e streaming.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 7300' },
      { label: 'Memória RAM', value: '8 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB ou 512 GB' },
      { label: 'Tela', value: '6,67" P-OLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 32 MP' },
      { label: 'Bateria', value: '5.200 mAh (Carregamento 30W)' },
      { label: 'Sistema', value: 'Android 15 (My UX)' },
      { label: 'Recursos', value: 'IP68/IP69, NFC, Conectividade 5G, Resistência a quedas 1,2 metros' }
    ],
    highlights: [
      { title: 'Design', text: 'Sistema de design moderno e resistente com acabamento premium nas cores Lilás e Preto.' },
      { title: 'Resistência', text: 'Projetado para ser robusto, com boa resistência a quedas.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias e streaming, jogos e multitarefa.' }
    ],
    gallery: ['Motorola/g86-1.png', 'Motorola/g86-2.png', 'Motorola/g86-3.png', 'Motorola/g86-4.png']
  },
  {
    id: 17,
    brand: 'Motorola',
    name: 'EDGE 50 5G FUSION',
    highlight: true,
    image: 'Motorola/edge50-1.png',
    price: 'A partir de R$ 1.999',
    description: 'O Moto Edge 50 5G Fusion é um smartphone linha pro que se destaca pela sua conectividade 5G, bateria, design, tela e performance em câmera.',
    specs: [
      { label: 'Processador', value: 'Snapdragon 7s Gen 2 ou Snapdragon 6 Gen 1' },
      { label: 'Memória RAM', value: '8 GB ou 12 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB, 256 GB ou 512 GB' },
      { label: 'Tela', value: '6,7" P-OLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 32 MP' },
      { label: 'Bateria', value: '5.000 mAh (Carregamento 68W)' },
      { label: 'Sistema', value: 'Android 14 (My UX)' },
      { label: 'Recursos', value: 'IP68, NFC, Conectividade 5G' }
    ],
    highlights: [
      { title: 'Conectividade', text: 'Suporte a redes 5G para internet mais rápida.' },
      { title: 'Resistência e Performance', text: 'Projetado para ser robusto, com boa resistência a quedas, jogo de câmeras incrível e performance.' },
      { title: 'Design', text: 'Corpo fino (7,9 mm) acabamento premium, disponível nas cores Pink, Azul Escuro e Azul Claro.' }
    ],
    gallery: ['Motorola/edge50-1.png', 'Motorola/edge50-2.png', 'Motorola/edge50-3.png', 'Motorola/edge50-4.png']
  },
  {
    id: 18,
    brand: 'Motorola',
    name: 'EDGE 60 5G FUSION',
    highlight: true,
    image: 'Motorola/edge60-1.png',
    price: 'A partir de R$ 2.299',
    description: 'O Moto Edge 60 5G Fusion é um smartphone de alto desempenho com design moderno e tela P-OLED de alta resolução.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 7300' },
      { label: 'Memória RAM', value: '8 GB ou 12 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB ou 512 GB' },
      { label: 'Tela', value: '6,67" P-OLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 32 MP' },
      { label: 'Bateria', value: '5.200 mAh (Carregamento 68W)' },
      { label: 'Sistema', value: 'Android 15 (My UX)' },
      { label: 'Recursos', value: 'IP68/IP69, NFC, Conectividade 5G' }
    ],
    highlights: [
      { title: 'Desempenho', text: 'Processador Mediatek Dimensity 7300 para uma experiência fluida.' },
      { title: 'Design', text: 'Tela P-OLED com resolução FHD+ e taxa de atualização de até 120 Hz, nas cores Rosa, Preto e Azul.' },
      { title: 'Câmeras', text: 'Câmera principal de 50 MP e frontal de 32 MP para selfies nítidas.' }
    ],
    gallery: ['Motorola/edge60-1.png', 'Motorola/edge60-2.png', 'Motorola/edge60-3.png', 'Motorola/edge60-4.png']
  },
  {
    id: 19,
    brand: 'Redmi',
    name: 'REDMI A5',
    highlight: false,
    image: 'Redmi/a5-1.png',
    price: 'A partir de R$ 899',
    description: 'O Redmi A5 é um smartphone de entrada que se destaca pela sua bateria de 5.200 mAh, ideal para uso diário.',
    specs: [
      { label: 'Processador', value: 'Unisoc T7250' },
      { label: 'Memória RAM', value: '4 GB (+ virtual)' },
      { label: 'Armazenamento', value: '128 GB' },
      { label: 'Tela', value: '6,88" IPS LCD, HD+ 120 Hz' },
      { label: 'Câmeras', value: 'Principal 32 MP | Frontal 8 MP' },
      { label: 'Bateria', value: '5.200 mAh (Carregamento 15W)' },
      { label: 'Sistema', value: 'Android 15 (GO)' },
      { label: 'Recursos', value: 'IP54' }
    ],
    highlights: [
      { title: 'Custo Benefício', text: 'Projetado para oferecer um bom desempenho para tarefas básicas a um preço acessível.' },
      { title: 'Design', text: 'Corpo fino (8,9 mm) e disponível nas cores Preto, Verde, Dourado e Azul.' },
      { title: 'Performance', text: 'Adequado para tarefas diárias (redes sociais, apps de transporte).' }
    ],
    gallery: ['Redmi/a5-1.png', 'Redmi/a5-2.png', 'Redmi/a5-3.png', 'Redmi/a5-4.png']
  },
  {
    id: 20,
    brand: 'Redmi',
    name: 'NOTE 14 PRO',
    highlight: true,
    image: 'Redmi/note14pro-1.png',
    price: 'A partir de R$ 2.399',
    description: 'O Redmi Note 14 Pro é um smartphone de alto desempenho com design moderno e tela AMOLED de alta resolução.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 7300' },
      { label: 'Memória RAM', value: '8 GB ou 12 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB ou 512 GB' },
      { label: 'Tela', value: '6,67" AMOLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 200 MP | Frontal 20 MP' },
      { label: 'Bateria', value: '5.110 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 14 (HyperOS)' },
      { label: 'Recursos', value: 'IP68, Conectividade 5G, NFC' }
    ],
    highlights: [
      { title: 'Desempenho', text: 'Processador Dimensity 7300 para uma experiência fluida.' },
      { title: 'Design', text: 'Tela AMOLED com resolução FHD+ e taxa de atualização de até 120 Hz.' },
      { title: 'Câmeras', text: 'Câmera principal de 200 MP e frontal de 20 MP para selfies nítidas.' }
    ],
    gallery: ['Redmi/note14pro-1.png', 'Redmi/note14pro-2.png', 'Redmi/note14pro-3.png', 'Redmi/note14pro-4.png']
  },
  {
    id: 21,
    brand: 'Poco',
    name: 'POCO X7 5G',
    highlight: false,
    image: 'Poco/x7-1.png',
    price: 'A partir de R$ 1.899',
    description: 'O POCO X7 5G é um smartphone de alto desempenho que se destaca pela sua conectividade 5G, bateria, design resistente, ideal para uso gamer e streaming.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 7300 Ultra' },
      { label: 'Memória RAM', value: '8 GB ou 12 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB ou 512 GB' },
      { label: 'Tela', value: '6,67" AMOLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 20 MP' },
      { label: 'Bateria', value: '5.110 mAh (Carregamento 45W)' },
      { label: 'Sistema', value: 'Android 14 (HyperOS)' },
      { label: 'Recursos', value: 'IP69, NFC, Conectividade 5G' }
    ],
    highlights: [
      { title: 'Conectividade', text: 'Suporte a redes 5G para internet mais rápida.' },
      { title: 'Desempenho', text: 'Processador Mediatek Dimensity 7300 Ultra para uma experiência fluida.' },
      { title: 'Design', text: 'Tela AMOLED com resolução FHD+ e taxa de atualização de até 120 Hz.' }
    ],
    gallery: ['Poco/x7-1.png', 'Poco/x7-2.png', 'Poco/x7-3.png', 'Poco/x7-4.png']
  },
  {
    id: 22,
    brand: 'Poco',
    name: 'POCO X7 PRO',
    highlight: true,
    image: 'Poco/x7pro-1.png',
    price: 'A partir de R$ 2.799',
    description: 'O POCO X7 Pro é um smartphone de alto desempenho com design moderno e tela AMOLED de alta resolução, ideal para uso gamer e streaming.',
    specs: [
      { label: 'Processador', value: 'Mediatek Dimensity 8400 Ultra' },
      { label: 'Memória RAM', value: '8 GB ou 12 GB (+ virtual)' },
      { label: 'Armazenamento', value: '256 GB ou 512 GB' },
      { label: 'Tela', value: '6,67" AMOLED, FHD+, 120 Hz' },
      { label: 'Câmeras', value: 'Principal 50 MP | Frontal 20 MP' },
      { label: 'Bateria', value: '6.000 mAh (Carregamento 90W)' },
      { label: 'Sistema', value: 'Android 14 (HyperOS)' },
      { label: 'Recursos', value: 'IP68/IP69, NFC, Conectividade 5G' }
    ],
    highlights: [
      { title: 'Desempenho', text: 'Processador Mediatek Dimensity 8400 Ultra para uma experiência fluida.' },
      { title: 'Design', text: 'Tela AMOLED com resolução FHD+ e taxa de atualização de até 120 Hz.' },
      { title: 'Câmeras', text: 'Câmera principal de 50 MP e frontal de 20 MP para selfies nítidas.' }
    ],
    gallery: ['Poco/x7pro-1.png', 'Poco/x7pro-2.png', 'Poco/x7pro-3.png', 'Poco/x7pro-4.png']
  },
  {
    id: 23,
    brand: 'iPhone',
    name: 'LINHA IPHONE',
    highlight: true,
    specialPrice: 'Sob Consulta',
    image: 'iPhone/iphone-1.png',
    price: 'A partir de R$ 3.899',
    description: 'A linha iPhone é conhecida por seu design premium, desempenho excepcional e integração perfeita com o ecossistema Apple.',
    specs: [
      { label: 'Processador', value: 'Apple' },
      { label: 'Memória RAM', value: '6 GB (iPhone 15 Pro)' },
      { label: 'Armazenamento', value: '128 GB, 256 GB, 512 GB ou 1 TB' },
      { label: 'Tela', value: '6,1" ou 6,7" Super Retina XDR OLED' },
      { label: 'Câmeras', value: 'Sistema de câmeras avançado' },
      { label: 'Bateria', value: 'Duração variável, geralmente um dia inteiro' },
      { label: 'Sistema', value: 'iOS' },
      { label: 'Recursos', value: 'Face ID, resistência à água IP68, carregamento MagSafe' }
    ],
    highlights: [
      { title: 'Desempenho', text: 'Processador Apple A17 Pro para uma experiência fluida e rápida.' },
      { title: 'Design', text: 'Construção premium em aço inoxidável e vidro, disponível em várias cores.' },
      { title: 'Câmeras', text: 'Sistema de câmeras avançado com recursos como modo noturno e gravação em 4K.' }
    ],
    gallery: ['iPhone/iphone-1.png', 'iPhone/iphone-2.png', 'iPhone/iphone-3.png', 'iPhone/iphone-4.png']
  }
];

export const brands = ['Todos', 'Realme', 'Honor', 'Motorola', 'Redmi', 'Poco', 'iPhone'];

export interface Store {
  name: string;
  logo: string;
  address: string;
  cep: string;
  mapUrl: string;
  instagram: string;
  instagramHandle: string;
  facebook: string;
  facebookName: string;
  whatsapp: string;
  whatsappDisplay: string;
}

export const storesPiracicaba: Store[] = [
  {
    name: 'Miplace XV de Novembro',
    logo: 'logo/xv (1).jpg',
    address: 'R. Quinze de Novembro, 910 - Centro',
    cep: '13400-370',
    mapUrl: 'https://maps.google.com/?q=R.+Quinze+de+Novembro,+910+-+Centro,+Piracicaba+-+SP',
    instagram: 'https://instagram.com/miplace.xvdenovembro',
    instagramHandle: '@miplace.xvdenovembro',
    facebook: 'https://www.facebook.com/share/1G15m1Tcu8/?mibextid=wwXIfr',
    facebookName: 'Miplace XV de Novembro',
    whatsapp: 'https://wa.me/5519989605504',
    whatsappDisplay: '(19) 98960-5504'
  },
  {
    name: 'Miplace Honor',
    logo: 'logo/dp (1).jpg',
    address: 'R. Dom Pedro II, 857 - Centro',
    cep: '13400-390',
    mapUrl: 'https://maps.google.com/?q=R.+Dom+Pedro+II,+857+-+Centro,+Piracicaba+-+SP',
    instagram: 'https://instagram.com/miplace.dompedro',
    instagramHandle: '@miplace.dompedro',
    facebook: 'https://www.facebook.com/share/1AXgkFAVgQ/?mibextid=wwXIfr',
    facebookName: 'Miplace Honor',
    whatsapp: 'https://wa.me/5519994975131',
    whatsappDisplay: '(19) 99497-5131'
  },
  {
    name: 'Miplace Realme',
    logo: 'logo/realme (1).jpg',
    address: 'R. Benjamin Constant, 1230 - Centro',
    cep: '13400-053',
    mapUrl: 'https://maps.google.com/?q=R.+Benjamin+Constant,+1230+-+Centro,+Piracicaba+-+SP',
    instagram: 'https://instagram.com/miplace.benjamin',
    instagramHandle: '@miplace.benjamin',
    facebook: 'https://www.facebook.com/share/1KgggPkqQL/?mibextid=wwXIfr',
    facebookName: 'Miplace Realme',
    whatsapp: 'https://wa.me/5519994510123',
    whatsappDisplay: '(19) 99451-0123'
  }
];

export const storesAmparo: Store[] = [
  {
    name: 'Miplace Kassouf',
    logo: 'logo/kf (1).jpg',
    address: 'R. Treze de Maio, 218 - sala 09 - Centro',
    cep: '13900-005',
    mapUrl: 'https://maps.google.com/?q=R.+Treze+de+Maio,+218+-+Centro,+Amparo+-+SP',
    instagram: 'https://instagram.com/miplace.kassouf',
    instagramHandle: '@miplace.kassouf',
    facebook: 'https://www.facebook.com/share/1ASHdG4hNB/?mibextid=wwXIfr',
    facebookName: 'Miplace Kassouf',
    whatsapp: 'https://wa.me/5519971077066',
    whatsappDisplay: '(19) 97107-7066'
  },
  {
    name: 'Miplace Premium',
    logo: 'logo/pr (1).jpg',
    address: 'R. Treze de Maio, 26 - Centro',
    cep: '13900-005',
    mapUrl: 'https://maps.google.com/?q=R.+Treze+de+Maio,+26+-+Centro,+Amparo+-+SP',
    instagram: 'https://instagram.com/miplace.premium',
    instagramHandle: '@miplace.premium',
    facebook: 'https://www.facebook.com/share/1DYqbVuA7G/?mibextid=wwXIfr',
    facebookName: 'Miplace Premium',
    whatsapp: 'https://wa.me/5519999618865',
    whatsappDisplay: '(19) 99961-8865'
  }
];

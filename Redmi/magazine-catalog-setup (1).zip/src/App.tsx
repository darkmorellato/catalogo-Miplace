import { useState, useEffect, useCallback, useRef } from 'react';
import { productsData, brands, storesPiracicaba, storesAmparo, type Product, type Store } from './data/products';

/* ──────────────────────── AUDIO HELPERS ──────────────────────── */
let audioCtx: AudioContext | null = null;
function getAudioCtx() {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
  }
  return audioCtx;
}

function playUIClick() {
  try {
    const ctx = getAudioCtx();
    if (ctx.state === 'suspended') ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(50, ctx.currentTime + 0.05);
    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  } catch { /* silently fail */ }
}

/* ──────────────────────── SCROLL PROGRESS ──────────────────────── */
function ScrollProgress() {
  const [width, setWidth] = useState(0);
  useEffect(() => {
    const handler = () => {
      const st = document.documentElement.scrollTop || document.body.scrollTop;
      const h = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      setWidth(h > 0 ? (st / h) * 100 : 0);
    };
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);
  return <div className="fixed top-0 left-0 h-1 bg-accent z-[60] transition-all duration-100 ease-out" style={{ width: `${width}%` }} />;
}

/* ──────────────────────── PAPER GRAIN OVERLAY ──────────────────────── */
function PaperGrain() {
  return <div className="paper-grain" />;
}

/* ──────────────────────── CONTACT DROPDOWN ──────────────────────── */
function ContactDropdown() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  const stores = [
    { city: 'Piracicaba, SP', items: storesPiracicaba },
    { city: 'Amparo, SP', items: storesAmparo }
  ];

  return (
    <div className="relative z-50" ref={ref}>
      <button onClick={() => { playUIClick(); setOpen(!open); }} className="hover:text-ink font-bold underline decoration-1 underline-offset-4 flex items-center gap-2 cursor-pointer">
        Contato Direto
        <i className={`fa-solid fa-chevron-down text-[10px] transition-transform duration-300 ${open ? 'rotate-180' : ''}`} />
      </button>
      <div className={`absolute right-0 top-full pt-4 w-60 transition-all duration-300 text-left ${open ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
        <div className="bg-paper border border-ink shadow-2xl flex flex-col py-2">
          {stores.map((group) => (
            <div key={group.city}>
              <span className="text-[9px] text-ink-light px-4 py-2 uppercase tracking-[0.2em] font-bold bg-paper-dark block">{group.city}</span>
              {group.items.map((s) => (
                <a key={s.name} href={`${s.whatsapp}`} target="_blank" rel="noopener noreferrer" className="px-4 py-3 text-xs font-bold hover:bg-ink hover:text-paper transition-colors flex items-center gap-3" onClick={playUIClick}>
                  <div className="w-6 h-6 rounded-full bg-paper-dark border border-ink/20 flex items-center justify-center overflow-hidden flex-shrink-0">
                    <i className="fa-solid fa-store text-[8px] text-ink-light" />
                  </div>
                  {s.name}
                </a>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────── HEADER ──────────────────────── */
function Header() {
  return (
    <header className="w-full pt-10 pb-6 px-4 md:px-8 bg-paper border-b-thick border-ink z-40 relative mt-3">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center text-xs md:text-sm font-sans uppercase tracking-widest text-ink-light mb-6">
          <span>Edição Especial 2026 by Dark Morellato</span>
          <span className="hidden md:block">Piracicaba & Amparo — SP</span>
          <ContactDropdown />
        </div>
        <div className="text-center">
          <h1 className="font-serif text-5xl md:text-8xl lg:text-9xl font-black uppercase tracking-tighter text-ink leading-none cursor-pointer" onClick={() => { playUIClick(); window.scrollTo({ top: 0, behavior: 'smooth' }); }}>
            Miplace
          </h1>
          <p className="font-sans text-sm md:text-base uppercase tracking-[0.3em] md:tracking-[0.5em] mt-4 font-medium">Tecnologia & Estilo de Vida</p>
        </div>
        <nav className="mt-10 flex flex-wrap justify-center gap-8 md:gap-16 border-t border-ink pt-4 font-sans text-sm uppercase tracking-widest font-bold">
          {[
            { href: '#inicio', label: 'Capa' },
            { href: '#editorial-boleto', label: 'Destaque' },
            { href: '#catalogo', label: 'A Coleção' },
            { href: '#enderecos', label: 'Endereços' },
          ].map(l => (
            <a key={l.href} href={l.href} className="hover:text-ink-light transition-colors relative group" onClick={playUIClick}>
              {l.label}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-ink transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>
      </div>
    </header>
  );
}

/* ──────────────────────── MARQUEE ──────────────────────── */
function Marquee() {
  const text = 'MIPLACE MAGAZINE • TECNOLOGIA PREMIUM • ESTILO DE VIDA • EDIÇÃO ESPECIAL • ';
  return (
    <div className="marquee-container relative z-30">
      <div className="marquee-content">{text.repeat(12)}</div>
    </div>
  );
}

/* ──────────────────────── REVEAL WRAPPER ──────────────────────── */
function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { el.classList.add('active'); obs.unobserve(el); } }, { threshold: 0.1 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return <div ref={ref} className={`reveal ${className}`}>{children}</div>;
}

/* ──────────────────────── HERO SECTION ──────────────────────── */
function HeroSection() {
  return (
    <section id="inicio" className="max-w-7xl mx-auto px-4 md:px-8 py-12 w-full">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12">
        <Reveal className="md:col-span-7 lg:col-span-8 relative flex items-center justify-center">
          <div className="w-full h-full min-h-[400px] md:min-h-[500px] flex flex-col justify-center items-center relative group p-0 md:p-4">
            <div className="relative w-full max-w-[700px] transition-transform duration-1000 group-hover:scale-105">
              <div className="absolute z-0 overflow-hidden bg-black" style={{ top: '4%', left: '2.5%', width: '96%', height: '84.5%', borderRadius: '42px' }}>
                <iframe src="https://www.youtube.com/embed/gwBz0OCk_hA?autoplay=1&mute=1&loop=1&playlist=gwBz0OCk_hA&controls=0&playsinline=1&modestbranding=1&rel=0" className="w-full h-full" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen style={{ pointerEvents: 'none' }} title="Video de apresentação" />
              </div>
              <img src="moldura-celular.png" alt="Mão segurando Smartphone" className="relative z-10 w-full h-auto drop-shadow-[0_20px_40px_rgba(0,0,0,0.15)] pointer-events-none" />
            </div>
          </div>
        </Reveal>

        <Reveal className="md:col-span-5 lg:col-span-4 flex flex-col justify-between">
          <div>
            <div className="border-double-thick mb-6 w-max">
              <span className="font-sans text-[10px] uppercase tracking-[0.3em] font-bold block pb-1 text-ink-light">Editorial de Apresentação</span>
            </div>
            <h3 className="font-serif font-black text-4xl md:text-5xl leading-[1.1] tracking-tighter mb-8 text-ink">
              Redefinindo o acesso à <br /><span className="font-light italic tracking-normal text-ink-light">alta tecnologia</span>
            </h3>
            <p className="font-sans text-ink-light text-base leading-relaxed mb-6 drop-cap">
              Uma curadoria exclusiva com as melhores marcas do mercado: <strong>Xiaomi, Apple, Realme, Honor e Motorola</strong>. Além da nossa linha premium de acessórios e a renomada proteção Rockspace.
            </p>
            <p className="font-sans text-ink-light text-base leading-relaxed border-l-2 border-ink pl-4 italic">
              Esqueça a burocracia. A Miplace revoluciona a forma como você adquire seu próximo smartphone.
            </p>
          </div>
          <div className="mt-10 pt-10 border-t border-ink">
            <a href="#catalogo" className="font-sans uppercase tracking-widest text-sm font-bold flex items-center justify-between group cursor-pointer" onClick={playUIClick}>
              <span>Ver a coleção completa</span>
              <i className="fa-solid fa-arrow-right transform group-hover:translate-x-2 transition-transform" />
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ──────────────────────── BOLETO SECTION ──────────────────────── */
function BoletoSection() {
  return (
    <section id="editorial-boleto" className="bg-ink text-paper py-20 my-12 border-y-[12px] border-paper-dark">
      <Reveal className="max-w-5xl mx-auto px-4 md:px-8 text-center">
        <h4 className="font-sans text-xs uppercase tracking-[0.4em] mb-6 text-paper/60">Vantagens de comprar na Miplace</h4>
        <h2 className="font-serif text-5xl md:text-7xl mb-8 leading-tight">Parcelamos em até 24 vezes,<br /> sem consulta.</h2>
        <div className="w-24 h-[1px] bg-paper/30 mx-auto mb-8" />
        <p className="font-sans text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-10 text-paper/80">
          A rede Miplace está há 7 anos no mercado, sendo precursora na venda de crediário. Adquira os lançamentos mais cobiçados do mercado através do nosso parcelamento exclusivo no boleto bancário. Uma facilidade pensada para você, com aprovação rápida e sem consulta de score.
        </p>
        <a href="#enderecos" className="inline-block bg-paper text-ink font-sans uppercase tracking-widest font-bold text-sm px-10 py-4 hover:bg-paper-dark transition-colors" onClick={playUIClick}>
          Fale com um Consultor
        </a>
      </Reveal>
    </section>
  );
}

/* ──────────────────────── PRODUCT CARD ──────────────────────── */
function ProductCard({ product, index, isFeatured, onOpenModal }: { product: Product; index: number; isFeatured: boolean; onOpenModal: (id: number) => void }) {
  const [imgIdx, setImgIdx] = useState(0);

  useEffect(() => {
    if (!product.gallery || product.gallery.length <= 1) return;
    const interval = setInterval(() => {
      setImgIdx(prev => (prev + 1) % product.gallery.length);
    }, 7000 + Math.random() * 3000);
    return () => clearInterval(interval);
  }, [product.gallery]);

  const gridClass = isFeatured
    ? "md:col-span-2 lg:col-span-2 border-b md:border-b-0 md:border-r border-ink pb-8 md:pb-0 md:pr-8"
    : "border-b border-ink/20 pb-8";
  const titleSize = isFeatured ? "text-4xl md:text-5xl" : "text-2xl";
  const microSpecs = product.specs.length > 0
    ? product.specs.slice(0, 2).map(s => { const p = s.value.split(' '); return p[0] + ' ' + (p[1] || ''); }).join(' • ')
    : '';

  return (
    <div className={`${gridClass} group flex flex-col justify-between h-full stagger-item`} style={{ animationDelay: `${index * 0.08}s` }}>
      <div>
        <div className="w-full aspect-video bg-paper-dark flex items-center justify-center mb-6 img-zoom-container relative cursor-pointer" onClick={() => { playUIClick(); onOpenModal(product.id); }}>
          {product.highlight && <span className="absolute top-4 left-4 bg-ink text-paper text-[10px] uppercase tracking-widest px-3 py-1.5 z-10">Destaque</span>}
          <div className="absolute inset-0 bg-ink/30 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-all duration-500 z-20 flex items-center justify-center">
            <span className="text-paper font-sans uppercase tracking-[0.2em] text-xs font-bold border border-paper px-6 py-3 hover:bg-paper hover:text-ink transition-colors transform translate-y-4 group-hover:translate-y-0 duration-500">Ver Detalhes</span>
          </div>
          {product.image ? (
            <img src={product.gallery[imgIdx] || product.image} alt={product.name} className="w-full h-full object-cover img-zoom transition-opacity duration-500" onError={(e) => { (e.target as HTMLImageElement).src = product.image; }} />
          ) : (
            <i className="fa-solid fa-mobile-screen text-5xl text-ink/20 img-zoom" />
          )}
        </div>
        <div className="flex justify-between items-end mb-3 border-b border-ink/10 pb-2">
          <span className="font-sans text-[10px] font-bold uppercase tracking-[0.2em] text-ink-light">{product.brand}</span>
          <span className="font-sans text-[9px] uppercase tracking-widest text-ink-light/60">Ref. {String(product.id).padStart(3, '0')}</span>
        </div>
        <h4 className={`font-serif ${titleSize} leading-none tracking-tight mb-2 text-ink group-hover:text-ink-light transition-colors`}>{product.name}</h4>
        {microSpecs && <p className="font-sans text-[10px] uppercase tracking-[0.15em] text-ink-light/70 truncate">{microSpecs}</p>}
      </div>
      <div className="mt-6 flex items-end justify-between border-t border-ink/10 pt-4">
        <div className="font-sans text-sm">
          {product.specialPrice ? (
            <span className="font-bold text-ink">{product.specialPrice}</span>
          ) : (
            <>
              <span className="block text-ink-light text-[10px] uppercase tracking-widest mb-1">Entre em Contato</span>
              <span className="font-bold text-xs leading-tight block">Confirmar disponibilidade</span>
            </>
          )}
        </div>
        <a href="#enderecos" className="w-8 h-8 flex items-center justify-center border border-ink/30 rounded-full group-hover:bg-ink group-hover:border-ink group-hover:text-paper transition-all duration-300" onClick={playUIClick} title="Consultar">
          <i className="fa-solid fa-arrow-right text-[10px] transform group-hover:translate-x-0.5 transition-transform" />
        </a>
      </div>
    </div>
  );
}

/* ──────────────────────── STORE CONTACTS (for modal) ──────────────────────── */
function StoreContacts({ stores, city, productName, onClose }: { stores: Store[]; city: string; productName: string; onClose: () => void }) {
  return (
    <div className="flex flex-col gap-4 animate-fade-in bg-paper p-6 shadow-[0_-15px_40px_rgba(0,0,0,0.15)] border border-ink z-50 max-h-[50vh] overflow-y-auto">
      <div className="flex justify-between items-center mb-2 pb-2 border-b border-ink/20">
        <span className="font-sans text-[10px] font-bold uppercase tracking-widest text-ink-light">Lojas em {city}</span>
        <button onClick={onClose} className="text-ink hover:text-red-600 transition-colors" title="Fechar"><i className="fa-solid fa-xmark" /></button>
      </div>
      {stores.map(s => (
        <div key={s.name} className="bg-paper-dark p-4 border-l-4 border-ink">
          <h5 className="font-serif font-bold text-lg mb-2">{s.name}</h5>
          <div className="flex flex-col gap-2">
            <a href={`${s.whatsapp}?text=${encodeURIComponent(`Olá! Gostaria de saber mais sobre o ${productName}.`)}`} target="_blank" rel="noopener noreferrer" className="text-sm font-sans font-bold flex items-center gap-2 hover:text-green-700 transition-colors w-max" onClick={playUIClick}>
              <i className="fa-brands fa-whatsapp text-lg" /> {s.whatsappDisplay}
            </a>
            <a href={s.mapUrl} target="_blank" rel="noopener noreferrer" className="text-xs font-sans text-ink-light flex items-center gap-2 hover:text-ink transition-colors w-max" onClick={playUIClick}>
              <i className="fa-solid fa-map-location-dot text-base" /> {s.address}
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ──────────────────────── PRODUCT MODAL ──────────────────────── */
function ProductModal({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const [showPira, setShowPira] = useState(false);
  const [showAmp, setShowAmp] = useState(false);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  useEffect(() => {
    setShowPira(false);
    setShowAmp(false);
  }, [product]);

  if (!product) return null;

  const galleryImages = product.gallery.length > 0 ? product.gallery : (product.image ? [product.image] : []);

  return (
    <div className="fixed inset-0 z-[100] flex flex-col justify-center items-center animate-fade-in">
      <div className="absolute inset-0 bg-ink/90 backdrop-blur-sm cursor-pointer" onClick={onClose} />
      <div className="bg-paper relative z-10 w-full max-w-6xl max-h-[95vh] min-h-[60vh] overflow-y-auto flex flex-col md:flex-row shadow-2xl m-4">
        <button onClick={() => { playUIClick(); onClose(); }} className="absolute top-4 right-4 w-10 h-10 bg-ink text-paper rounded-full flex items-center justify-center hover:scale-110 transition-transform z-20 shadow-lg">
          <i className="fa-solid fa-xmark" />
        </button>
        <div className="w-full md:w-5/12 bg-paper-dark relative min-h-[300px] border-r border-ink/10">
          <div className="md:absolute inset-0 p-8 md:p-12 overflow-y-auto flex flex-col justify-start items-center">
            <div className="w-full flex flex-col gap-12">
              {galleryImages.map((img, i) => (
                <div key={i} className="w-full max-w-sm mx-auto aspect-[4/5] bg-transparent flex items-center justify-center cursor-zoom-in group transition-colors" title="Clique para ampliar">
                  <img src={img} alt={`${product.name} ${i + 1}`} className="w-full h-full object-contain drop-shadow-2xl group-hover:scale-105 transition-transform duration-500" />
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="w-full md:w-7/12 p-8 md:p-12 flex flex-col bg-paper">
          <div className="mb-2 flex justify-between items-center">
            <span className="font-sans text-[10px] font-bold uppercase tracking-[0.2em] text-ink-light">{product.brand}</span>
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 leading-none">{product.name}</h2>
          {product.price && <p className="font-sans text-xl font-bold border-b-2 border-ink pb-4 mb-6 inline-block w-max">{product.price}</p>}
          <p className="font-sans text-sm md:text-base text-ink-light leading-relaxed mb-6">{product.description}</p>

          {product.highlights.length > 0 && (
            <div className="mt-8">
              <h4 className="font-sans text-xs uppercase tracking-[0.2em] font-bold mb-4">Destaques</h4>
              <ul className="space-y-4">
                {product.highlights.map((h, i) => (
                  <li key={i} className="font-sans text-sm">
                    <strong className="block mb-1">{h.title}</strong>
                    <span className="text-ink-light leading-relaxed">{h.text}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {product.specs.length > 0 && (
            <div className="mt-8 border-t border-ink pt-6">
              <h4 className="font-sans text-xs uppercase tracking-[0.2em] font-bold mb-4">Ficha Técnica</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-4 gap-x-8 text-sm font-sans">
                {product.specs.map((spec, i) => (
                  <div key={i} className="border-b border-ink/10 pb-2">
                    <span className="block text-ink-light text-[10px] uppercase tracking-widest">{spec.label}</span>
                    <span className="font-medium">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-10 pt-8 border-t border-ink w-full relative">
            <h4 className="font-sans text-xs uppercase tracking-[0.2em] font-bold mb-4">Escolha a cidade para comprar</h4>
            <div className="relative w-full">
              {showPira && (
                <div className="absolute bottom-full left-0 w-full mb-4">
                  <StoreContacts stores={storesPiracicaba} city="Piracicaba" productName={product.name} onClose={() => setShowPira(false)} />
                </div>
              )}
              {showAmp && (
                <div className="absolute bottom-full left-0 w-full mb-4">
                  <StoreContacts stores={storesAmparo} city="Amparo" productName={product.name} onClose={() => setShowAmp(false)} />
                </div>
              )}
              <div className="flex flex-col sm:flex-row gap-4 mb-2">
                <button onClick={() => { playUIClick(); setShowPira(!showPira); setShowAmp(false); }} className="flex-1 bg-ink text-paper font-sans uppercase tracking-widest font-bold text-xs px-4 py-4 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_10px_20px_rgba(28,25,23,0.3)] flex items-center justify-center gap-2">
                  <i className="fa-solid fa-location-dot" /> Piracicaba
                </button>
                <button onClick={() => { playUIClick(); setShowAmp(!showAmp); setShowPira(false); }} className="flex-1 border border-ink text-ink bg-paper font-sans uppercase tracking-widest font-bold text-xs px-4 py-4 transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_10px_20px_rgba(28,25,23,0.3)] hover:bg-ink hover:text-paper flex items-center justify-center gap-2">
                  <i className="fa-solid fa-location-dot" /> Amparo
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ──────────────────────── CATALOG SECTION ──────────────────────── */
function CatalogSection() {
  const [filter, setFilter] = useState('Todos');
  const [modalProduct, setModalProduct] = useState<Product | null>(null);

  const filtered = filter === 'Todos' ? productsData : productsData.filter(p => p.brand === filter);

  const openModal = useCallback((id: number) => {
    const p = productsData.find(pr => pr.id === id);
    if (p) { setModalProduct(p); document.body.style.overflow = 'hidden'; }
  }, []);

  const closeModal = useCallback(() => {
    playUIClick();
    setModalProduct(null);
    document.body.style.overflow = 'auto';
  }, []);

  return (
    <>
      <section id="catalogo" className="max-w-7xl mx-auto px-4 md:px-8 py-16 w-full">
        <Reveal className="flex flex-col md:flex-row justify-between items-end mb-12 border-b-thick border-ink pb-6">
          <div>
            <h2 className="font-serif text-5xl md:text-7xl font-black tracking-tighter">A <span className="font-light italic tracking-normal">Coleção</span></h2>
            <p className="font-sans uppercase tracking-[0.3em] text-xs mt-4 text-ink-light font-bold">Selecione uma marca para explorar</p>
          </div>
          <div className="sticky top-3 z-40 bg-paper/95 backdrop-blur-md py-4 flex flex-wrap gap-6 mt-8 md:mt-0 font-sans text-xs uppercase tracking-widest font-bold transition-all">
            {brands.map(b => (
              <button key={b} onClick={() => { playUIClick(); setFilter(b); }} className={`relative pb-1 transition-colors ${filter === b ? 'text-ink border-b-2 border-ink' : 'text-ink-light hover:text-ink'}`}>
                {b}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-12 gap-x-8" key={filter}>
          {filtered.map((p, i) => (
            <ProductCard key={p.id} product={p} index={i} isFeatured={i === 0} onOpenModal={openModal} />
          ))}
        </div>

        <Reveal className="mt-24 pt-12 border-t border-ink grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="font-serif text-3xl mb-4">Acessórios & Proteção</h3>
            <p className="font-sans text-ink-light mb-6">Fones, microfones, carregadores, cabos e a exclusiva película de proteção Rockspace.</p>
          </div>
          <div className="md:text-right">
            <a href="#enderecos" className="font-sans uppercase tracking-widest text-sm font-bold border border-ink px-8 py-3 hover:bg-ink hover:text-paper transition-colors inline-block" onClick={playUIClick}>
              Consultar Estoque
            </a>
          </div>
        </Reveal>
      </section>

      {modalProduct && <ProductModal product={modalProduct} onClose={closeModal} />}
    </>
  );
}

/* ──────────────────────── STORE CARD (Addresses Section) ──────────────────────── */
function StoreCard({ store }: { store: Store }) {
  return (
    <div className="group flex flex-col sm:flex-row justify-between sm:items-end border-b border-ink/20 pb-6 hover:border-ink transition-colors">
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-paper-dark border border-ink/20 flex items-center justify-center overflow-hidden flex-shrink-0">
          <i className="fa-solid fa-store text-xl text-ink-light" />
        </div>
        <div>
          <h4 className="font-serif text-2xl font-bold mb-2">{store.name}</h4>
          <a href={store.mapUrl} target="_blank" rel="noopener noreferrer" className="font-sans text-sm text-ink-light max-w-xs hover:text-ink transition-colors block hover:underline" onClick={playUIClick}>
            <i className="fa-solid fa-map-location-dot mr-1" /> {store.address}<br />CEP: {store.cep}
          </a>
        </div>
      </div>
      <div className="flex flex-col items-start sm:items-end gap-2 mt-4 sm:mt-0">
        <a href={store.instagram} target="_blank" rel="noopener noreferrer" className="font-sans text-sm font-bold flex items-center gap-2 hover:text-pink-600 transition-colors" onClick={playUIClick}>
          <i className="fa-brands fa-instagram text-lg" /> {store.instagramHandle}
        </a>
        <a href={store.facebook} target="_blank" rel="noopener noreferrer" className="font-sans text-sm font-bold flex items-center gap-2 hover:text-blue-600 transition-colors" onClick={playUIClick}>
          <i className="fa-brands fa-facebook text-lg" /> {store.facebookName}
        </a>
        <a href={store.whatsapp} target="_blank" rel="noopener noreferrer" className="font-sans text-sm font-bold flex items-center gap-2 hover:text-green-700 transition-colors" onClick={playUIClick}>
          <i className="fa-brands fa-whatsapp text-lg" /> {store.whatsappDisplay}
        </a>
      </div>
    </div>
  );
}

/* ──────────────────────── ADDRESSES SECTION ──────────────────────── */
function AddressesSection() {
  return (
    <section id="enderecos" className="bg-paper-dark py-20 mt-12 border-t border-ink">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <Reveal className="text-center mb-16">
          <h2 className="font-serif text-5xl md:text-6xl mb-4">Encontre a Miplace mais próxima:</h2>
          <div className="w-16 h-[2px] bg-ink mx-auto" />
        </Reveal>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <Reveal className="lg:col-span-6">
            <h3 className="font-sans uppercase tracking-[0.3em] text-lg font-bold border-b border-ink pb-4 mb-8">Piracicaba, SP</h3>
            <div className="space-y-8">
              {storesPiracicaba.map(s => <StoreCard key={s.name} store={s} />)}
            </div>
          </Reveal>
          <Reveal className="lg:col-span-6">
            <h3 className="font-sans uppercase tracking-[0.3em] text-lg font-bold border-b border-ink pb-4 mb-8">Amparo, SP</h3>
            <div className="space-y-8">
              {storesAmparo.map(s => <StoreCard key={s.name} store={s} />)}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ──────────────────────── FOOTER ──────────────────────── */
function Footer() {
  return (
    <footer className="bg-ink text-paper pt-24 pb-8 text-center font-sans relative overflow-hidden flex flex-col items-center justify-between min-h-[45vh]">
      <div className="relative z-10 w-full px-4 mb-16">
        <p className="text-[10px] uppercase tracking-[0.4em] text-paper/50 mb-4">Fim da Edição</p>
        <div className="w-12 h-[2px] bg-paper/30 mx-auto mb-12" />
        <div className="flex flex-wrap justify-center items-center gap-6 md:gap-16 text-xs uppercase tracking-widest text-paper/70 mb-16 font-bold">
          <a href="#inicio" className="hover:text-paper hover:underline underline-offset-4 transition-all" onClick={playUIClick}>Voltar à Capa</a>
          <a href="#catalogo" className="hover:text-paper hover:underline underline-offset-4 transition-all" onClick={playUIClick}>Revisitar Coleção</a>
          <a href="#enderecos" className="hover:text-paper hover:underline underline-offset-4 transition-all" onClick={playUIClick}>Nossas Lojas</a>
        </div>
        <p className="text-[10px] uppercase tracking-[0.3em] text-paper/40 mb-4">
          Rede Miplace © 2026. Todos os direitos reservados.
        </p>
        <p className="text-[9px] uppercase tracking-[0.2em] text-paper/20 max-w-md mx-auto leading-relaxed">
          Marcas mencionadas pertencem aos seus respectivos proprietários.<br />
          O parcelamento no boleto está sujeito a análise e condições da loja física.
        </p>
      </div>
      <div className="w-full flex justify-center mt-auto opacity-5 select-none pointer-events-none translate-y-8">
        <h2 className="font-serif text-[18vw] md:text-[20vw] leading-[0.7] font-black uppercase tracking-tighter text-paper m-0">
          Miplace
        </h2>
      </div>
    </footer>
  );
}

/* ──────────────────────── MAIN APP ──────────────────────── */
export default function App() {
  return (
    <div className="antialiased min-h-screen flex flex-col relative">
      <PaperGrain />
      <ScrollProgress />
      {/* Top frame bar */}
      <div className="h-3 bg-ink w-full fixed top-0 z-50" />
      <Header />
      <Marquee />
      <HeroSection />
      <BoletoSection />
      <CatalogSection />
      <AddressesSection />
      <Footer />
    </div>
  );
}

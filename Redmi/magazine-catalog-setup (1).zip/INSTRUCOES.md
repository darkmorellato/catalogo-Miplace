# 📋 GUIA COMPLETO — Como Montar o Projeto no Visual Studio Code

---

## 📌 PRÉ-REQUISITOS (instalar ANTES de começar)

### 1. Node.js (obrigatório)
- Acesse: https://nodejs.org/
- Baixe a versão **LTS** (recomendada)
- Instale normalmente (próximo, próximo, finalizar)
- Para verificar se instalou, abra o **terminal** e digite:
```
node --version
npm --version
```
- Ambos devem mostrar um número de versão (ex: `v20.11.0` e `10.2.0`)

### 2. Visual Studio Code (obrigatório)
- Acesse: https://code.visualstudio.com/
- Baixe e instale normalmente

---

## 🚀 PASSO A PASSO PARA MONTAR O PROJETO

### PASSO 1 — Criar a pasta do projeto

1. Crie uma pasta no seu computador, por exemplo:
   - `C:\Projetos\miplace-magazine` (Windows)
   - `~/Projetos/miplace-magazine` (Mac/Linux)

### PASSO 2 — Abrir no VS Code

1. Abra o **Visual Studio Code**
2. Vá em **Arquivo > Abrir Pasta** (ou `Ctrl+K Ctrl+O`)
3. Selecione a pasta `miplace-magazine` que você criou

### PASSO 3 — Criar os arquivos

Dentro da pasta do projeto, crie **exatamente** esta estrutura de arquivos e pastas:

```
miplace-magazine/
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── public/                    ← Pasta para imagens dos produtos
│   ├── moldura-celular.png
│   ├── Realme/
│   │   ├── c61-1.png
│   │   ├── c61-2.png
│   │   ├── c61-3.png
│   │   ├── c61-4.png
│   │   ├── c63-1.png
│   │   ├── ... (demais imagens)
│   ├── Honor/
│   │   ├── x5c-1.png
│   │   ├── ... (demais imagens)
│   ├── Motorola/
│   │   ├── g05-1.png
│   │   ├── ... (demais imagens)
│   ├── Redmi/
│   │   ├── a5-1.png
│   │   ├── ... (demais imagens)
│   ├── Poco/
│   │   ├── x7-1.png
│   │   ├── ... (demais imagens)
│   ├── iPhone/
│   │   ├── iphone-1.png
│   │   ├── ... (demais imagens)
│   └── logo/
│       ├── xv (1).jpg
│       ├── dp (1).jpg
│       ├── realme (1).jpg
│       ├── kf (1).jpg
│       └── pr (1).jpg
└── src/
    ├── main.tsx
    ├── App.tsx
    ├── index.css
    ├── utils/
    │   └── cn.ts
    └── data/
        └── products.ts
```

**Para criar pastas e arquivos no VS Code:**
- Clique no ícone de **"Nova Pasta"** 📁 no painel lateral esquerdo (Explorer)
- Clique no ícone de **"Novo Arquivo"** 📄 no painel lateral esquerdo (Explorer)

### PASSO 4 — Copiar o conteúdo de cada arquivo

Copie o conteúdo de cada arquivo que está neste projeto. Os arquivos são:

| Arquivo | Descrição |
|---------|-----------|
| `index.html` | Página HTML base |
| `package.json` | Lista de dependências do projeto |
| `tsconfig.json` | Configuração do TypeScript |
| `vite.config.ts` | Configuração do Vite (bundler) |
| `src/main.tsx` | Ponto de entrada do React |
| `src/App.tsx` | Componente principal (todo o site) |
| `src/index.css` | Estilos CSS + Tailwind |
| `src/utils/cn.ts` | Utilitário de classes CSS |
| `src/data/products.ts` | Dados dos produtos (catálogo) |

### PASSO 5 — Instalar as dependências

1. No VS Code, abra o **Terminal** integrado:
   - Menu: **Terminal > Novo Terminal** (ou atalho: `` Ctrl+` ``)
   
2. No terminal que abriu (deve estar na pasta do projeto), digite:
```bash
npm install
```

3. Aguarde terminar (pode demorar 1-2 minutos). Vai aparecer algo como:
```
added 150 packages, and audited 151 packages in 30s
```

> ⚠️ Uma pasta `node_modules` será criada automaticamente. **NÃO apague ela.**

### PASSO 6 — Rodar o projeto em modo desenvolvimento

No terminal, digite:
```bash
npm run dev
```

Vai aparecer algo como:
```
  VITE v7.2.4  ready in 300 ms

  ➜  Local:   http://localhost:5173/
  ➜  Network: http://192.168.1.100:5173/
```

1. Segure `Ctrl` e clique no link `http://localhost:5173/`
2. O site vai abrir no navegador! 🎉

> **Para parar o servidor:** pressione `Ctrl+C` no terminal.

### PASSO 7 — Gerar a versão final (build para produção)

Quando o site estiver pronto para publicar:

```bash
npm run build
```

Os arquivos finais serão gerados na pasta `dist/`. O arquivo `dist/index.html` é o site completo pronto para subir em qualquer servidor.

---

## 🖼️ SOBRE AS IMAGENS DOS PRODUTOS

As imagens dos produtos devem ser colocadas na pasta `public/`. Exemplo:

- `public/Realme/c61-1.png` → aparece como `Realme/c61-1.png` no site
- `public/moldura-celular.png` → aparece como `moldura-celular.png` no site
- `public/logo/xv (1).jpg` → aparece como `logo/xv (1).jpg` no site

**IMPORTANTE:**
- Os nomes dos arquivos e pastas são **case-sensitive** (maiúsculas e minúsculas importam)
- `Realme` ≠ `realme` — use exatamente como está no código
- Formatos aceitos: `.png`, `.jpg`, `.jpeg`, `.webp`

---

## 🎵 SOBRE A MÚSICA DE FUNDO

O código original tinha uma música de fundo. Nesta versão React, o botão de música foi removido para simplificar. Se quiser adicionar de volta:

1. Coloque o arquivo `.mp3` na pasta `public/`
2. Adicione a lógica de áudio no componente `App`

---

## ❓ PROBLEMAS COMUNS

### "npm não é reconhecido como comando"
→ O Node.js não foi instalado corretamente. Reinstale pelo site https://nodejs.org/

### "ENOENT: no such file or directory"
→ Você não está na pasta correta no terminal. Use `cd nome-da-pasta` para navegar.

### As imagens não aparecem
→ Verifique se:
1. As imagens estão na pasta `public/`
2. Os nomes estão exatamente iguais (incluindo maiúsculas/minúsculas)
3. A extensão está correta (.png ou .jpg)

### O site aparece em branco
→ Abra o console do navegador (`F12` > aba `Console`) e veja a mensagem de erro.

---

## 🌐 COMO PUBLICAR O SITE

### Opção 1: Vercel (gratuito e recomendado)
1. Crie uma conta em https://vercel.com/
2. Instale o Vercel CLI: `npm i -g vercel`
3. No terminal do projeto: `vercel`
4. Siga as instruções na tela

### Opção 2: Netlify (gratuito)
1. Rode `npm run build`
2. Acesse https://app.netlify.com/drop
3. Arraste a pasta `dist/` para a página

### Opção 3: Servidor próprio / Hospedagem
1. Rode `npm run build`
2. Suba o conteúdo da pasta `dist/` para o servidor via FTP

---

## 📁 ESTRUTURA FINAL DO PROJETO

Após o `npm install`, sua pasta ficará assim:

```
miplace-magazine/
├── dist/                      ← Gerada pelo "npm run build"
├── node_modules/              ← Gerada pelo "npm install" (NÃO MEXER)
├── public/                    ← Suas imagens vão aqui
│   ├── moldura-celular.png
│   ├── Realme/
│   ├── Honor/
│   ├── Motorola/
│   ├── Redmi/
│   ├── Poco/
│   ├── iPhone/
│   └── logo/
├── src/
│   ├── main.tsx
│   ├── App.tsx
│   ├── index.css
│   ├── utils/
│   │   └── cn.ts
│   └── data/
│       └── products.ts
├── index.html
├── package.json
├── tsconfig.json
├── vite.config.ts
├── INSTRUCOES.md              ← Este arquivo
└── package-lock.json          ← Gerado automaticamente
```
